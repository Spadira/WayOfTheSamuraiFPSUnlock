================================================================
  Way of the Samurai 3 (PC) - Framerate Patch
  60 / 90 / 120 fps gameplay, with cutscenes kept at 30 fps
================================================================

WHAT IT DOES
------------
The PC port runs at a hard 30 fps. This patch raises the gameplay
framerate while keeping the game running at the correct speed.

Cutscenes are deliberately left at 30 fps. Their sequencing (camera
cuts, scene timing) is tied to the render rate, so running them at
30 keeps them paced exactly as the developers authored them. The
patch detects cutscenes automatically and switches back and forth.

What is fixed along the way:
  * game and combat speed stay correct at the higher framerate
  * animation-driven sound effects fire once, not twice
  * scripted waits keep their intended duration
  * motion blending is doubled, so transitions are smoother


REQUIREMENTS
------------
The DRM-free GOG build of Way of the Samurai 3.

  Known-good WayOfTheSamurai3.exe
    size   : 5,697,536 bytes
    SHA256 : ED1552D19EF3FAA7959510EEB22D3A69B9B4A180A5C00923238FDA7EF3E00301

Other builds are NOT supported, but trying is safe: the patcher
checks all 18 patch sites byte-for-byte against your exe and refuses
to write anything if they do not match.


INSTALL
-------
1. Copy Install.bat, patch.ps1 and "Switch Framerate.bat" into the
   game folder - the one containing WayOfTheSamurai3.exe.
2. Run Install.bat.

It backs up your original exe to WayOfTheSamurai3.exe.orig, builds the
60/90/120 fps variants, and installs 60 fps. No admin rights needed.


SWITCHING
---------
Run "Switch Framerate.bat" and pick:

   [1]  30 fps   - original, completely unmodified
   [2]  60 fps   - recommended, play-tested
   [3]  90 fps   - EXPERIMENTAL, not play-tested
   [4]  120 fps  - EXPERIMENTAL, not play-tested

Close the game first; Windows will not replace a running exe.

60 fps is the only build that has actually been played through.
90 and 120 are built the same way and verified to launch and apply
correctly, but nobody has played them - hence "experimental". 120 fps
in particular may not be sustainable: this is a single-threaded 2009
port, so the limiter will aim for 120 but the CPU may not keep up.


UNINSTALL
---------
Run "Switch Framerate.bat" and choose [1]. That restores the original
exe exactly. You can then delete the .60fps_v9 / .90fps_v9 /
.120fps_v9 files and the patch files if you want.


STEAM VERSION
-------------
Untested - this was developed against the GOG build only.

Just run Install.bat and see. If the Steam exe happens to be the same
build, it will work. If it differs at all, the patcher stops and tells
you, without modifying anything.

Be aware the Steam release may be wrapped in SteamStub DRM, which
encrypts the executable's code section on disk. If so the patch sites
cannot match and the patcher will refuse - that is expected, not a bug,
and it is not something this patch can work around.


TECHNICAL SUMMARY
-----------------
170 bytes changed across 18 sites. Three small code caves are placed in
the zero-filled slack at the end of the .text section, so the file
layout and section sizes are untouched.

  * frame gate (0x403510) - each frame sets the frame interval to
    1/30 when the engine is in event mode, otherwise 1/<target>.
    Event mode is the engine's own state: [[0x94dadc]+0x70] == 2 or 3,
    the same field 27 call sites in the script/scene code gate on.
  * script Wait (0x56845c) - wait counts are authored for 30 fps, so
    they are scaled by target/30 during gameplay and left alone in
    cutscenes.
  * animation sound-key window (0x42e319) - the window is one authored
    frame wide, which spans two rendered frames at 60 fps and makes
    every animation sound fire twice. Now derived from the live frame
    interval, so it is correct at any rate.
  * motion blend length (0x430f2c, 0x431945) - doubled.
  * SetFrameRate (0x4034d1) - startup default.

The engine's content rate stays at 30 throughout. That matters: it is
the divisor for every frames-to-seconds conversion in the game, and
raising it is what makes animations and hit timing go wrong.


LICENCE / SHARING
-----------------
This package contains NO game files - only scripts that modify your own
legally obtained copy. Share it freely.

No warranty. It edits an executable; keep the .orig backup.
